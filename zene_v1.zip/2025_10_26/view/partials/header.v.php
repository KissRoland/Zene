<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Zenelejátszási lista</title>
</head>
<body>
    <nav class="navbar is-primary" role="navigation">
        <div class="navbar-brand">
            <a class="navbar-item" href="index.php?page=home">🎵 Playlist App</a>
        </div>
        <div class="navbar-menu">
            <div class="navbar-start">
                <a class="navbar-item" href="index.php?page=playlist">Lejátszási lista</a>
                <a class="navbar-item" href="index.php?page=add_track">Új zeneszám</a>
            </div>
        </div>
    </nav>
