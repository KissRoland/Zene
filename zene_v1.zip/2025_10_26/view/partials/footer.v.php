    <footer class="footer mt-6">
        <div class="content has-text-centered">
            <p>
                <strong>Playlist App</strong> – Minden jog fenntartva 2025.
            </p>
        </div>
    </footer>
</body>
</html>
