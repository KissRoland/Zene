<?php
$tracks = get_all_tracks();
$dur = get_total_playlist_duration();
$genres = array_unique(array_column($tracks, 'genre'));
$years = array_column($tracks, 'year');
?>
<section class="section">
    <div class="container">
        <h1 class="title">Statisztika</h1>
        <ul>
            <li>Összes zeneszám: <?= count($tracks) ?></li>
            <li>Teljes hossz: <?= floor($dur / 3600) ?> óra <?= floor(($dur % 3600) / 60) ?> perc</li>
            <li>Műfajok száma: <?= count($genres) ?></li>
            <li>Legrégebbi év: <?= min($years) ?></li>
            <li>Legújabb év: <?= max($years) ?></li>
            <li>Átlagos hossz: <?= format_duration(intval($dur / count($tracks))) ?></li>
        </ul>
    </div>
</section>
