<?php
$page = $_GET['page'] ?? 'home';
include_once 'app/functions.php';
include_once 'app/view_functions.php';
include_once 'view/partials/header.v.php';
include_once "view/pages/{$page}.v.php";
include_once 'view/partials/footer.v.php';
