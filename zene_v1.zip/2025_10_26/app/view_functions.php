<?php
function format_duration(int $seconds): string {
    return floor($seconds / 60) . ':' . str_pad($seconds % 60, 2, '0', STR_PAD_LEFT);
}

function render_genre_tag(string $genre): string {
    return "<span class='tag is-info is-light'>$genre</span>";
}

function render_track_row(array $track): string {
    return "
    <tr>
        <td>{$track['title']}</td>
        <td>{$track['performer']}</td>
        <td>{$track['album']}</td>
        <td>" . format_duration($track['length']) . "</td>
        <td>" . render_genre_tag($track['genre']) . "</td>
        <td>{$track['year']}</td>
    </tr>";
}
