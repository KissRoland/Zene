<?php
function get_all_tracks(): array {
    $file = __DIR__ . '/../data/tracks.json';
    if (!file_exists($file)) return [];
    $json = file_get_contents($file);
    return json_decode($json, true) ?? [];
}

function filter_tracks_by_genre(string $genre): array {
    return array_filter(get_all_tracks(), fn($track) => $track['genre'] === $genre);
}

function get_total_playlist_duration(): int {
    return array_sum(array_column(get_all_tracks(), 'length'));
}

function get_tracks_by_decade(int $decade): array {
    return array_filter(get_all_tracks(), fn($track) => floor($track['year'] / 10) * 10 === $decade);
}
