<?php
function save_track(array $track): void {
    $tracks = get_all_tracks();
    $track['id'] = count($tracks) + 1;
    $tracks[] = $track;
    file_put_contents(__DIR__ . '/../data/tracks.json', json_encode($tracks, JSON_PRETTY_PRINT));
}
