    <footer>
        <p><strong>Playlist App</strong> Minden jog fenntartva 2025.</p>
    </footer>
</body>
</html>
