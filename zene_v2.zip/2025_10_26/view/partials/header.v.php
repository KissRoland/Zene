<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Zenelejátszási lista</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <ul class="nav">
            <li><a href="index.php?page=home">Főoldal</a></li>
            <li><a href="index.php?page=playlist">Lejátszási lista</a></li>
            <li><a href="index.php?page=add_track">Új zeneszám</a></li>
        </ul>
    </nav>
