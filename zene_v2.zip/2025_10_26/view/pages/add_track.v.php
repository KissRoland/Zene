<?php
$errors = [];
$genres = ['rock','pop','hip-hop','jazz','elektronikus','klasszikus','metal','country','r&b','indie'];
$submitted = $_SERVER['REQUEST_METHOD'] === 'POST';

if ($submitted) {
    $title = trim($_POST['title'] ?? '');
    $performer = trim($_POST['performer'] ?? '');
    $album = trim($_POST['album'] ?? '');
    $length = (int)($_POST['length'] ?? 0);
    $genre = $_POST['genre'] ?? '';
    $year = (int)($_POST['year'] ?? 0);

    if (strlen($title) < 2) $errors[] = "A cím legalább 2 karakter legyen.";
    if (strlen($performer) < 2) $errors[] = "Az előadó neve legalább 2 karakter legyen.";
    if (strlen($album) < 2) $errors[] = "Az album neve legalább 2 karakter legyen.";
    if ($length <= 0 || $length > 1200) $errors[] = "A hossz 1 és 1200 másodperc között legyen.";
    if (!in_array($genre, $genres)) $errors[] = "Érvénytelen műfaj.";
    if ($year < 1950 || $year > 2025) $errors[] = "Az év 1950 és 2025 között legyen.";

    if (empty($errors)) {
        $newTrack = compact('title', 'performer', 'album', 'length', 'genre', 'year');
        save_track($newTrack);
        echo "<div class='notification is-success'>Sikeres mentés!</div>";
    }
}
?>

<section class="section">
    <div class="container">
        <h1 class="title">Új zeneszám hozzáadása</h1>

        <?php if (!empty($errors)): ?>
            <div class="notification is-danger">
                <ul>
                    <?php foreach ($errors as $e): ?>
                        <li><?= $e ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post">
            <div class="field">
                <label class="label">Cím</label>
                <div class="control">
                    <input class="input" type="text" name="title" value="<?= $_POST['title'] ?? '' ?>">
                </div>
            </div>

            <div class="field">
                <label class="label">Előadó</label>
                <div class="control">
                    <input class="input" type="text" name="performer" value="<?= $_POST['performer'] ?? '' ?>">
                </div>
            </div>

            <div class="field">
                <label class="label">Album</label>
                <div class="control">
                    <input class="input" type="text" name="album" value="<?= $_POST['album'] ?? '' ?>">
                </div>
            </div>

            <div class="field">
                <label class="label">Hossz (másodperc)</label>
                <div class="control">
                    <input class="input" type="number" name="length" value="<?= $_POST['length'] ?? '' ?>">
                </div>
            </div>

            <div class="field">
                <label class="label">Műfaj</label>
                <div class="control">
                    <div class="select">
                        <select name="genre">
                            <option value="">Válassz...</option>
                            <?php foreach ($genres as $g): ?>
                                <option value="<?= $g ?>" <?= ($_POST['genre'] ?? '') === $g ? 'selected' : '' ?>><?= ucfirst($g) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="field">
                <label class="label">Év</label>
                <div class="control">
                    <input class="input" type="number" name="year" value="<?= $_POST['year'] ?? '' ?>">
                </div>
            </div>

            <div class="control">
                <button class="button is-primary">Mentés</button>
            </div>
        </form>
    </div>
</section>
